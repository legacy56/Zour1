# UOR 1 — versión Flutter

Port del `index.html` del panel UOR 1 a Flutter (Android).

## Compilar el APK sin instalar nada (GitHub Actions)
1. Creá un repo en GitHub y subí **el contenido de esta carpeta** (con `.github/`).
2. Pestaña **Actions → Build APK → Run workflow**.
3. Al terminar, bajá **uor1-apk** desde *Artifacts* (es un zip con `app-release.apk`).

## Compilar en una PC
```
flutter create . --platforms=android --project-name uor1 --org ar.gob.uor1
flutter pub get
dart run flutter_launcher_icons
flutter build apk --release
```
Después agregá a `android/app/src/main/AndroidManifest.xml` el bloque `<queries>` que está en el workflow (para SMS, enlaces y abrir archivos).
