// GENERADO desde index.html: contenido de las guías (antes eran modales)

sealed class Bloque {
  const Bloque();
}

class Sub extends Bloque {
  final String t;
  const Sub(this.t);
}

class Parrafo extends Bloque {
  final String m; // marcado simple: <b>negrita</b> <i>cursiva</i>
  const Parrafo(this.m);
}

class Lista extends Bloque {
  final List<String> items;
  const Lista(this.items);
}

class Ley extends Bloque {
  final String m;
  const Ley(this.m);
}

class TextoActa extends Bloque {
  final String t;
  const TextoActa(this.t);
}

class Documento extends Bloque {
  final String asset;
  final String titulo;
  final String detalle;
  const Documento(this.asset, this.titulo, this.detalle);
}

class Guia {
  final String id;
  final String titulo;
  final List<Bloque> bloques;
  const Guia(this.id, this.titulo, this.bloques);
}

const Map<String, Guia> guias = {
  'modalDetalle': Guia('modalDetalle', 'ℹ️ Acerca de esta página', [
    Parrafo('Esta herramienta fue creada para facilitar el trabajo diario del personal de la Guardia Provincial — Unidad Operativa Regional N° 1, reuniendo en un solo lugar accesos rápidos a organismos de control (RTO, SENASA, CPE), guías resumidas de procedimiento (exceso de peso, requisa y secuestro) y un buscador de códigos de infracciones de tránsito, con la misma consulta rápida que se usa en la PDA.'),
    Parrafo('También incluye el marco normativo actualizado — <b>Régimen Penal Juvenil (Ley 27.801)</b> y <b>Ley de Microtráfico (Ley 14.239)</b> — con modelos de acta y lectura de derechos listos para copiar, además de la guía de actuación ante un delito federal de mayor cantidad o impacto, y el <b>Protocolo Policial de Activación Automática para Delitos en Flagrancia</b>, descargable en PDF.'),
    Parrafo('Realizada por el <b>Oficial de Policía Zapata Gonzalo</b> como aporte para agilizar y ordenar las tareas operativas de rutas.'),
  ]),
  'modalBalanza': Guia('modalBalanza', '⚖️ Exceso de Peso — Qué hacer', [
    Sub('1. Dominio a cargar'),
    Lista(['Siempre el del <b>vehículo tractor</b> (el que traccina) — <b>NUNCA</b> el del acoplado, aunque haya uno o más o sea un chasis.', 'Todos los datos según la <b>cédula de identificación del vehículo</b>.', 'Cédula con Personería Jurídica → pedir CUIT de la empresa.', 'Si el conductor se niega → la infracción recae solo sobre su DNI.']),
    Sub('2. Código de infracción'),
    Lista(['Cargar código <b>17062</b>. Abre automáticamente el campo del equipo de pesaje (igual que alcoholemias).', 'Seleccionar el <b>par de balanzas</b> correspondiente (ya pre cargadas).', 'Completar <b>"MEDICIÓN OBTENIDA"</b> con el exceso detectado.']),
    Sub('3. Fotos ⚠️ (solo 2 espacios en la PDA)'),
    Lista(['<b>Foto 1 (obligatoria):</b> el comprobante de peso de la DPV, antes de entregarlo al infractor.', '<b>Foto 2 (sugerida):</b> el camión y acoplados, viendo tractor y ejes.', 'No es necesario filmar/fotografiar el momento del pesaje en sí.']),
    Sub('4. Campo "Observaciones"'),
    Lista(['No repetir datos ya presentes en el acta o comprobante.', 'Agregar solo: dominios de vehículos traccionados y tipo de carga (combustible, piedras, cereal, etc.).']),
    Sub('5. Juzgado de faltas'),
    Lista(['Solo seleccionar la región: Santa Fe, Rosario, Rafaela, Venado Tuerto o Reconquista.', 'Excepción: si la orden operativa lo indica o se retiene documentación/vehículo → indicar juzgado puntual.']),
    Sub('📄 Después de labrar el acta'),
    Lista(['Entregar copia del comprobante de peso (por duplicado) al infractor; la otra copia queda en la DPV.', 'Si se niega a firmar → asentar "Se niega a firmar".', 'Notificar 30 días para pago voluntario con 50% de descuento, solo en Juzgado SIJAI.']),
  ]),
  'modalArma': Guia('modalArma', '🔫 Requisa y Secuestro de Arma', [
    Sub('Marco previo — Control vehicular'),
    Parrafo('Operativo público de prevención dispuesto por Orden de Servicio, con fiscalización pública, ostensible y no discriminatoria de vehículos, en ejercicio de las facultades de prevención y control del tránsito y la seguridad pública.'),
    Parrafo('Se hace seña de detención, se identifica al conductor y se verifica documentación del vehículo y habilitación para conducir.'),
    Sub('Requisa vehicular'),
    Parrafo('Ante motivos objetivos que fundan sospecha, se procede a la requisa del rodado, hallando en su interior un arma de fuego (ej: escopeta cal. 16).'),
    Ley('<b>Art. 219 C.P.P.</b> Autoriza la requisa de vehículos cuando existan motivos suficientes para presumir que en él se ocultan cosas relacionadas con un delito.'),
    Sub('Aprehensión'),
    Parrafo('Por haber sido sorprendido en posesión de un arma de fuego sin exhibir documentación que acredite su tenencia o portación legal, conducta que <i>prima facie</i> configura el delito del art. 189 bis del Código Penal.'),
    Ley('<b>Art. 213, inc. a) C.P.P.</b> Supuesto de flagrancia / circunstancias que hacen presumir vinculación con un delito.'),
    Ley('<b>Art. 212 C.P.P.</b> Aprehensión sin orden judicial (facultad de la autoridad preventora).'),
    Sub('Secuestro y cadena de custodia'),
    Parrafo('Se practica el secuestro preventivo del arma, labrando por separado: acta de secuestro, cadena de custodia y rótulo correspondiente, con descripción del elemento y destino dado.'),
    Ley('<b>Art. 240 C.P.P.</b> Secuestro de elementos vinculados al delito.'),
    Sub('📚 Resumen de artículos — CPP Santa Fe (Ley 12.734, conf. Ley 14.258)'),
    Lista(['<b>Art. 212:</b> Aprehensión sin orden judicial.', '<b>Art. 213, inc. a):</b> Flagrancia / sospecha vinculada a delito.', '<b>Art. 219:</b> Requisa personal y de vehículos.', '<b>Art. 240:</b> Secuestro de elementos vinculados al delito.']),
    Ley('<b>Art. 189 bis Código Penal</b> — tenencia/portación ilegal de arma de fuego.'),
    Sub('📋 Texto para el acta (listo para copiar)'),
    TextoActa('Que, encontrándose el nombrado en las circunstancias previstas por el art. 213, inc. a) del Código Procesal Penal (Ley 12.734, conf. Ley 14.258), por haber sido sorprendido en posesión de un arma de fuego (ejemplo: calibre 16) sin exhibir documentación que acredite su tenencia o portación legal, conducta que prima facie configuraría el delito previsto en el art. 189 bis del Código Penal, se procede a su APREHENSIÓN en los términos del art. 212 del C.P.P.\nSe practica el secuestro preventivo del arma conforme art. 240 del C.P.P., labrándose por separado acta de secuestro, cadena de custodia y rótulo correspondiente.'),
  ]),
  'modalMenores': Guia('modalMenores', '🧒 Régimen Penal Juvenil — Ley 27.801', [
    Parrafo('Vigente desde el 05/09/2026. Promulgada por Decreto 138/2026, publicado en el Boletín Oficial. Sustituye a la Ley 22.278 (vigente desde 1980), que establecía que los menores de 16 años no eran punibles.'),
    Sub('1. Edad de imputabilidad'),
    Parrafo('Baja de 16 a <b>14 años</b>. Los adolescentes de 14 y 15 años pueden ser imputados y sometidos a proceso penal. El régimen comprende a quienes tengan entre 14 años y hasta las cero horas del día en que cumplen 18. Se toma en cuenta la edad que tenía el adolescente al momento del hecho investigado.'),
    Sub('2. Escala de penas'),
    Lista(['Prohibida la prisión y reclusión perpetua para menores de 18, aunque el delito la contemple para un adulto.', 'Condena máxima: <b>15 años</b>, aunque la suma de varios delitos arroje una pena superior.', 'Delitos con pena de hasta 3 años: no puede imponerse prisión efectiva.', 'Delitos con pena de más de 3 y hasta 10 años: el juez puede evaluar medidas alternativas según informes técnicos y situación particular del adolescente.', 'La privación de libertad puede cumplirse en domicilio, instituto abierto o centro especializado.', 'Si no hubo muerte ni violencia física/psíquica grave, y no hay otras causas en trámite, el juez puede reemplazar la prisión por medidas más leves — pero ya no está obligado: necesita dictamen pericial, acuerdo del fiscal y haber escuchado a la víctima.']),
    Sub('3. Rol de las provincias'),
    Parrafo('Invita a provincias y CABA a adecuar sus legislaciones procesales. En Santa Fe, la Ley provincial 12.967 deberá articularse con este nuevo piso de imputabilidad.'),
    Sub('📊 Antes / Ahora'),
    Ley('<b>14-15 años — antes:</b> no punible, solo medidas tutelares.'),
    Ley('<b>14-15 años — ahora:</b> punible, proceso penal pleno, sin perpetua, máx. 15 años.'),
    Ley('<b>16-17 años — antes:</b> punible solo en delitos con pena mayor a 2 años.'),
    Ley('<b>16-17 años — ahora:</b> mismo régimen general 14-18, mismas garantías y topes de pena.'),
    Sub('📋 Al labrar el acta de detención (14-15 años)'),
    Lista(['Tratarlo como imputado, con las garantías reforzadas del régimen juvenil.', 'Comunicación inmediata a padres/tutor y al Fiscal/Juzgado de Menores en turno.', 'Presencia obligatoria de defensor antes de cualquier acto que lo requiera.', 'Nunca alojarlo junto a detenidos mayores.', 'Dejar constancia expresa de la edad exacta al momento del hecho.']),
  ]),
  'modalMicrotrafico': Guia('modalMicrotrafico', '🧪 Ley de Microtráfico — Ley Provincial 14.239', [
    Parrafo('Vigente desde el 29/12/2023. Desfederaliza la competencia penal en microtráfico/narcomenudeo (tenencia para comercialización al menudeo, entrega gratuita u onerosa en pequeñas cantidades y destinada directamente al consumidor final), que pasa a ser investigado por el Ministerio Público de la Acusación de Santa Fe — PDI (División Microtráfico) y las UFE-MT (Unidades Fiscales Especializadas en Microtráfico). La cadena de comercialización mayorista, producción, contrabando y eslabones superiores siguen bajo competencia de la Justicia Federal (Ley 23.737).'),
    Ley('<b>Art. 3:</b> pautas de intervención gradual, monitoreada, integrada a una política de mejora de calidad de vida, con participación de organismos estatales y comunidades afectadas.'),
    Parrafo('La provincia queda facultada para desactivar el punto de venta (búnker), incluso con demolición forzosa de construcciones precarias montadas para la venta. El narcotráfico de mayor escala, la producción de estupefacientes y los casos que exceden el menudeo quedan siempre en Justicia Federal.'),
    Sub('¿Cuándo es Microtráfico (Provincial) y cuándo es Federal?'),
    Lista(['<b>Queda en Provincial (Ley 14.239):</b> cantidades compatibles con venta al menudeo/consumo, sin otros indicios de organización, sin armas de fuego, sin sumas de dinero relevantes ni logística de transporte a gran escala.', '<b>Pasa a Federal:</b> cantidad de sustancia claramente superior al menudeo, hallazgo de balanzas de precisión, material de fraccionamiento en gran escala, armas de fuego, sumas de dinero relevantes, vehículos/rutas usados para transporte interprovincial, o cuando aparecen indicios de una organización o cadena de comercialización mayor.', '<b>Regla práctica:</b> ante la duda, siempre se da aviso a la Justicia Federal (fiscalía federal en turno o guardia del Juzgado Federal); es la propia Fiscalía la que decide y dispone la competencia, no el personal policial en el lugar del hecho.']),
    Sub('Procedimiento — control vehicular con secuestro'),
    Lista(['<b>Detección:</b> a simple vista o por indicios objetivos (olor, envoltorio, comportamiento del conductor, manifestación espontánea).', '<b>Regla de oro:</b> nunca "afirmar" qué sustancia es. No se es perito ni químico: se describe objetivamente lo que se ve (color, textura, olor), se pesa y se embala, siempre "compatible en apariencia con" y "sujeto a pericia".', '<b>Testigos y filmación:</b> 2 testigos hábiles, mayores de 18, ajenos a la repartición; filmación del procedimiento desde su inicio; fotos del hallazgo antes de manipular los elementos.', '<b>Requisa:</b> art. 219 CPP Santa Fe — motivos suficientes para presumir que en el vehículo se ocultan elementos vinculados a un delito.', '<b>Pesaje provisorio:</b> peso bruto aproximado, "sujeto a pericia"; se embala y precinta, numerando cada envoltorio y dejando constancia de quién lo embaló y trasladó.', '<b>Remisión:</b> al Gabinete de Criminalística / Laboratorio de la PDI (o de Gendarmería si interviene la Justicia Federal), para identificación, pureza y peso neto exacto.']),
    Sub('Puntos comunes a toda acta'),
    Lista(['Nunca afirmar la sustancia como hecho consumado — siempre "compatible en apariencia con", "sujeto a pericia".', 'Peso: siempre "bruto" y "aproximado" hasta que el laboratorio determine el peso neto.', 'Pureza: 100% librado al informe pericial químico.', 'Cadena de custodia: cada envoltorio numerado, quién lo embaló, quién lo trasladó y a qué dependencia se remitió.', 'Dejar constancia expresa de que el personal actuante no reviste idoneidad técnica ni científica para determinar la naturaleza exacta de lo secuestrado.']),
    Sub('📋 Modelo de acta — Cannabis (marihuana)'),
    TextoActa('En el marco del procedimiento, se procede al secuestro de [cantidad] envoltorio/s conteniendo en su interior una sustancia vegetal desmenuzada, de color verde parduzco, con olor característico, compatible en apariencia con la sustancia conocida vulgarmente como "marihuana", arrojando un peso bruto aproximado de _____ gramos/kilogramos, procediéndose a su embalaje y precintado bajo acta N° _____, quedando sujeto a la pericia química correspondiente a los fines de determinar fehacientemente su naturaleza, pureza y peso neto.\n\nSe deja expresa constancia que el personal actuante no reviste idoneidad técnica ni científica para determinar la naturaleza exacta de la sustancia secuestrada, por lo que la descripción consignada responde a las características externas observables (color, textura, olor), quedando su identificación definitiva sujeta al peritaje químico pertinente.'),
    Sub('📋 Modelo de acta — Cocaína (sustancia en polvo)'),
    TextoActa('En el marco del procedimiento, se procede al secuestro de [cantidad] envoltorio/s conteniendo en su interior una sustancia de aspecto pulverulento, de color blanco, compatible en apariencia con la sustancia conocida vulgarmente como "cocaína", arrojando un peso bruto aproximado de _____ gramos/kilogramos, procediéndose a su embalaje y precintado bajo acta N° _____, quedando sujeto a la pericia química correspondiente a los fines de determinar fehacientemente su naturaleza, pureza y peso neto.\n\nSe deja expresa constancia que el personal actuante no reviste idoneidad técnica ni científica para determinar la naturaleza exacta de la sustancia secuestrada, por lo que la descripción consignada responde a las características externas observables (color, textura, olor), quedando su identificación definitiva sujeta al peritaje químico pertinente.'),
    Sub('📋 Lectura de derechos al imputado por estupefacientes'),
    TextoActa('Siendo las _____ horas del día ___ de ___ de ___, personal de la Policía de la Provincia de Santa Fe, [unidad/dependencia], procede a hacer saber al ciudadano/a _____ que ha sido detenido, quedando incomunicado y a disposición del Juzgado Federal en turno, en el marco de la causa caratulada por [Dirección de Narcocriminalidad / Fiscalía Federal interviniente], dejándose constancia de la filmación de la presente diligencia desde su inicio y en presencia de dos testigos.\n\nSe le hace saber de sus derechos, a saber:\n\nSe le garantiza la plena vigencia de los derechos constitucionales consagrados en el Art. 18 de la Constitución Nacional.\n\nTiene derecho a designar un abogado que lo asista y represente; si no lo hace, el Estado le designará uno.\n\nPodrá entrevistar a su defensor en sede policial, únicamente con autorización del Juzgado Federal interviniente.\n\nA su indagatoria podrán asistir su defensor y el Fiscal Federal.\n\nNo será obligado a declarar sobre el hecho que se le atribuye; solo se le formularán preguntas relativas a sus datos personales.\n\nPodrá solicitar ser escuchado por el Fiscal, y que se le informen los hechos que se le atribuyen, su calificación legal provisoria y la prueba existente en su contra.'),
  ]),
  'modalFederal': Guia('modalFederal', '🏛️ Procedimiento Federal — Narcotráfico', [
    Parrafo('Se aplica cuando durante un control vehicular de rutina aparecen indicios de que el hecho excede el microtráfico (mayor cantidad de sustancia, manipulación visible del vehículo, armas, dinero en cantidad, logística de transporte). Ante la duda, siempre se da aviso a la Justicia Federal — es la propia Fiscalía la que decide y dispone la competencia, no el personal policial en el lugar del hecho.'),
    Sub('Cuándo y cómo proceder'),
    Lista(['<b>1. Aviso inmediato:</b> comunicación telefónica a la Justicia Federal (guardia del Juzgado Federal en turno) y a la Sede Fiscal Descentralizada, poniendo en conocimiento lo observado.', '<b>2. Autorización de requisa:</b> se solicita autorización al Juzgado Federal para la requisa del vehículo; el juzgado, previa comunicación con la fiscalía, autoriza la medida e imparte directivas.', '<b>3. Perímetro y seguridad:</b> con apoyo de la dependencia o unidad de apoyo que corresponda, se asegura el lugar y se da inicio a la requisa en presencia de los testigos ya convocados, con filmación desde el inicio.', '<b>4. Secuestro:</b> se incautan los paquetes/elementos hallados, dejando constancia de cantidad, envoltorio, ubicación exacta y todo otro elemento de interés (dinero, celulares, etc.), sin precisar composición exacta hasta la pericia.', '<b>5. Aprehensión:</b> conforme arts. 212 y 213 del CPP Santa Fe, se aprehende al conductor/involucrado en carácter de comunicado, informando a la Sede Fiscal.', '<b>6. Examen médico:</b> traslado del aprehendido a un nosocomio para revisión médica y constancia de lesiones (si las hubiere) antes de cualquier alojamiento.', '<b>7. Gendarmería Nacional:</b> por disposición de la Sede Fiscal, interviene Gendarmería para realizar la prueba de orientación de campo (narcotest) y el pesaje de la sustancia, haciéndose cargo del detenido, el vehículo y las actuaciones.', '<b>8. Defensor y derechos:</b> comunicación telefónica con el defensor (oficial o particular) y, con su presencia o autorización, notificación formal de derechos al imputado antes de cualquier acto que lo requiera.', '<b>9. Entrega de actuaciones:</b> se entrega todo lo labrado (actas, vehículo, sustancia, certificado médico, fotos y filmaciones, y el detenido) a la dependencia o autoridad que disponga la Fiscalía interviniente.']),
    Sub('📋 Modelo de acta — Procedimiento Federal (resumen, ejemplo)'),
    TextoActa('Siendo las _____ horas, en el marco de un operativo de control vehicular, se observa desde el exterior hacia el interior del vehículo que sus partes internas presentan signos de haber sido manipuladas, no guardando su originalidad, circunstancia que hace presumir la existencia de material estupefaciente adicional al hallado inicialmente. Ante la posibilidad de estar frente a un delito de interés federal, se da conocimiento de lo actuado a la Justicia Federal por vía telefónica, solicitándose autorización para la requisa del vehículo al Juzgado Federal interviniente, quien -previa comunicación con la Sede Fiscal Descentralizada- autoriza la medida.\n\nCon apoyo del personal de refuerzo convocado, se asegura el perímetro y se da inicio a la requisa en presencia de los testigos ya convocados y con filmación del procedimiento desde su inicio, procediéndose a la incautación de [cantidad] paquete/s compatible/s en apariencia con sustancia estupefaciente, hallado/s en [ubicación], como así también de [otros elementos secuestrados: dinero, celulares, balanzas, etc.], sin poder precisarse en este momento su composición ni cantidad exacta, quedando sujeto a la prueba de orientación de campo y a la pericia química correspondiente.\n\nConforme arts. 212 y 213 del Código Procesal Penal de Santa Fe, se procede a la APREHENSIÓN del ciudadano involucrado, en carácter de comunicado, dando aviso a la Sede Fiscal interviniente. Se dispone su traslado al nosocomio para examen médico, y por disposición fiscal se solicita la intervención de Gendarmería Nacional Argentina para la prueba de orientación en campo (narcotest) y pesaje de la sustancia, haciéndose cargo del detenido, el vehículo y las actuaciones correspondientes.\n\nSe deja expresa constancia de que el personal actuante no reviste idoneidad técnica ni científica para determinar la naturaleza exacta de lo secuestrado, quedando su identificación definitiva sujeta al peritaje pertinente.'),
    Sub('📋 Lectura de Derechos del Imputado (modelo general)'),
    TextoActa('Siendo las _____ horas, en este acto se le hace saber al ciudadano/a:\n\nQue reviste la calidad de imputado en la causa seguida en su contra.\n\nSe le garantiza la plena vigencia de los derechos constitucionales del art. 18 de la Constitución Nacional.\n\nTiene derecho a conocer los hechos que se le atribuyen y su calificación legal.\n\nTiene derecho a un abogado; si no lo hace, el Estado le designará uno.\n\nPodrá entrevistar a su defensor en forma libre, privada y confidencial.\n\nTiene derecho a guardar silencio, sin que ello se tome como indicio de culpabilidad.\n\nNo será obligado a declarar por el hecho investigado; solo se le formularán preguntas relativas a sus datos personales.'),
    Documento('assets/docs/acta_procedimiento_federal.docx', 'Descargar Acta de Procedimiento (Word)', 'modelo completo de procedimiento federal, para editar'),
    Documento('assets/docs/lectura_derechos_imputado.docx', 'Descargar Lectura de Derechos (Word)', 'modelo del imputado, para editar'),
  ]),
  'modalActasComplementarias': Guia('modalActasComplementarias', '🗂️ Actas Complementarias al Procedimiento', [
    Parrafo('Modelos en blanco, listos para descargar y completar a mano o en la compu.'),
    Documento('assets/docs/acta_aprehension_secuestro.doc', 'Acta de Aprehensión y Secuestro', 'DGPSV — Word'),
    Documento('assets/docs/acta_cadena_custodia.docx', 'Acta de Cadena de Custodia', 'Word'),
    Documento('assets/docs/formulario_cadena_custodia.odt', 'Formulario de Cadena de Custodia', 'ODT'),
    Documento('assets/docs/acta_entrevista_en_blanco.doc', 'Acta de Entrevista (en blanco)', 'Word'),
    Documento('assets/docs/acta_entrevista_modelo.doc', 'Acta de Entrevista (modelo extendido)', 'Word'),
    Documento('assets/docs/acta_resguardo_menor.doc', 'Acta de Resguardo del Menor', 'Word'),
    Documento('assets/docs/rotulo_elementos_acta_aprehension.doc', 'Rótulo de Elementos y Acta de Aprehensión', 'Word'),
    Documento('assets/docs/derechos_imputado_cpp.docx', 'Derechos del Imputado (Art. 268 inc. 12° CPP)', 'Word'),
  ]),
};
