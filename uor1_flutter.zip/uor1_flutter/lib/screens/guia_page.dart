import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import '../data/guias.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/action_button.dart';
import '../widgets/marcado.dart';

/// Copia el archivo del asset a una carpeta temporal y lo abre con la app instalada (Word, PDF, etc.).
Future<void> abrirDocumento(BuildContext context, String asset) async {
  try {
    final data = await rootBundle.load(asset);
    final dir = await getTemporaryDirectory();
    final nombre = asset.split('/').last;
    final file = File('${dir.path}/$nombre');
    await file.writeAsBytes(data.buffer.asUint8List(), flush: true);
    final res = await OpenFilex.open(file.path);
    if (res.type != ResultType.done && context.mounted) {
      toast(context, 'No hay una app para abrir este archivo (${res.message})');
    }
  } catch (e) {
    if (context.mounted) toast(context, 'No se pudo abrir el archivo');
  }
}

const _alias = 'usuario12';
const _cvu = '0000003100026331644795';

class GuiaPage extends StatelessWidget {
  final String guiaId;
  const GuiaPage({super.key, required this.guiaId});

  @override
  Widget build(BuildContext context) {
    final esApoyo = guiaId == 'modalApoyo';
    final guia = guias[guiaId];
    final titulo = esApoyo ? '💚 Ayudanos a seguir' : (guia?.titulo ?? '');
    return Scaffold(
      appBar: AppBar(
        backgroundColor: C.panel,
        foregroundColor: C.goldSoft,
        title: Text(titulo, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 28),
              children: [
                if (esApoyo) ..._apoyo(context) else ...guia!.bloques.map((b) => _bloque(context, b)),
                const SizedBox(height: 20),
                Center(
                  child: FilledButton(
                    onPressed: () => Navigator.of(context).pop(),
                    style: FilledButton.styleFrom(backgroundColor: Colors.white12, foregroundColor: C.ink, shape: const StadiumBorder()),
                    child: const Text('Cerrar', style: TextStyle(fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _apoyo(BuildContext context) => [
        const Text(
          'Esta app la armo y la mantengo en mis tiempos libres, con la idea de facilitar un poco el trabajo diario de la Guardia Provincial. No tiene publicidad ni fines comerciales. Si te resultó útil, cualquier aporte para que siga online y para poder sumar más herramientas y actualizaciones se agradece de corazón.',
          style: TextStyle(fontSize: 14, height: 1.6, color: C.inkDim),
        ),
        const SizedBox(height: 12),
        _DatoBox(label: 'Alias', valor: _alias),
        _DatoBox(label: 'CVU', valor: _cvu),
      ];

  Widget _bloque(BuildContext context, Bloque b) {
    const base = TextStyle(fontSize: 14, height: 1.6, color: C.inkDim);
    switch (b) {
      case Sub(:final t):
        return Padding(
          padding: const EdgeInsets.only(top: 16, bottom: 6),
          child: Text(t, style: const TextStyle(color: C.lime, fontSize: 15, fontWeight: FontWeight.w900)),
        );
      case Parrafo(:final m):
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Text.rich(TextSpan(style: base, children: parseMarcado(m, colorNegrita: C.ink))),
        );
      case Lista(:final items):
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final it in items)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Padding(padding: EdgeInsets.only(left: 6, right: 8), child: Text('•', style: base)),
                    Expanded(child: Text.rich(TextSpan(style: base, children: parseMarcado(it, colorNegrita: C.ink)))),
                  ]),
                ),
            ],
          ),
        );
      case Ley(:final m):
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 8),
          padding: const EdgeInsets.all(11),
          decoration: BoxDecoration(
            color: C.gold.withOpacity(0.07),
            border: const Border(left: BorderSide(color: C.gold, width: 3)),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text.rich(TextSpan(
            style: const TextStyle(fontSize: 13, height: 1.5, color: C.ink),
            children: parseMarcado(m, colorNegrita: C.goldSoft),
          )),
        );
      case TextoActa(:final t):
        return _TextoActa(texto: t);
      case Documento(:final asset, :final titulo, :final detalle):
        return Padding(
          padding: const EdgeInsets.only(top: 10),
          child: ActionButton(
            estilo: EstiloBoton.protocolo,
            icono: Icons.file_download_outlined,
            titulo: titulo,
            detalle: detalle,
            onTap: () => abrirDocumento(context, asset),
          ),
        );
    }
  }
}

class _TextoActa extends StatefulWidget {
  final String texto;
  const _TextoActa({required this.texto});
  @override
  State<_TextoActa> createState() => _TextoActaState();
}

class _TextoActaState extends State<_TextoActa> {
  bool _ok = false;

  Future<void> _copiar() async {
    final ok = await copiar(widget.texto);
    if (!mounted) return;
    if (!ok) {
      toast(context, 'No se pudo copiar automáticamente. Seleccioná el texto manualmente.');
      return;
    }
    setState(() => _ok = true);
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) setState(() => _ok = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.03),
          border: Border.all(color: C.line, width: 1.5),
          borderRadius: BorderRadius.circular(12),
        ),
        child: SelectableText(widget.texto,
            style: const TextStyle(fontSize: 13, height: 1.6, color: C.inkDim, fontStyle: FontStyle.italic)),
      ),
      const SizedBox(height: 8),
      FilledButton(
        onPressed: _copiar,
        style: FilledButton.styleFrom(
          backgroundColor: _ok ? C.lime : C.gold,
          foregroundColor: const Color(0xFF0A1C2B),
          shape: const StadiumBorder(),
        ),
        child: Text(_ok ? '✅ Copiado' : '📋 Copiar texto', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
      ),
    ]);
  }
}

class _DatoBox extends StatefulWidget {
  final String label;
  final String valor;
  const _DatoBox({required this.label, required this.valor});
  @override
  State<_DatoBox> createState() => _DatoBoxState();
}

class _DatoBoxState extends State<_DatoBox> {
  String _btn = 'Copiar';
  bool _ok = false;

  Future<void> _copiar() async {
    final ok = await copiar(widget.valor);
    if (!mounted) return;
    setState(() {
      _ok = ok;
      _btn = ok ? 'Copiado ✓' : 'No se pudo copiar';
    });
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) setState(() { _btn = 'Copiar'; _ok = false; });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.03),
        border: Border.all(color: C.line),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(children: [
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.label.toUpperCase(),
                style: const TextStyle(fontSize: 10, letterSpacing: 1.4, color: C.inkFaint, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(widget.valor, style: const TextStyle(fontFamily: 'monospace', fontSize: 14, color: C.ink)),
          ]),
        ),
        const SizedBox(width: 10),
        OutlinedButton(
          onPressed: _copiar,
          style: OutlinedButton.styleFrom(
            foregroundColor: _ok ? const Color(0xFF0A1C2B) : C.lime,
            backgroundColor: _ok ? C.lime : C.lime.withOpacity(0.1),
            side: BorderSide(color: C.lime.withOpacity(0.5), width: 1.5),
            shape: const StadiumBorder(),
          ),
          child: Text(_btn, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
        ),
      ]),
    );
  }
}
