import 'package:flutter/material.dart';
import '../theme.dart';
import 'guia_page.dart';
import 'home_page.dart';

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 320),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(40),
                    boxShadow: [BoxShadow(color: C.gold.withOpacity(0.55), blurRadius: 50)],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(40),
                    child: Image.asset('assets/img/icon-512.png', width: 230, height: 230),
                  ),
                ),
                const SizedBox(height: 24),
                const Text('UOR 1', style: TextStyle(fontSize: 32, fontWeight: FontWeight.w900, color: C.ink)),
                const SizedBox(height: 4),
                const Text('GUARDIA PROVINCIAL',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w800, letterSpacing: 3, color: C.goldSoft)),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      backgroundColor: C.lime,
                      foregroundColor: const Color(0xFF0A1C2B),
                      padding: const EdgeInsets.symmetric(vertical: 15),
                      shape: const StadiumBorder(),
                    ),
                    onPressed: () => Navigator.of(context).pushReplacement(
                        MaterialPageRoute(builder: (_) => const HomePage())),
                    child: const Text('INGRESAR', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1)),
                  ),
                ),
                const SizedBox(height: 14),
                OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: C.lime,
                    side: BorderSide(color: C.lime.withOpacity(0.4), width: 1.5),
                    shape: const StadiumBorder(),
                  ),
                  onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const GuiaPage(guiaId: 'modalApoyo'))),
                  child: const Text('💚 Apoyar este proyecto', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
