import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../data/codigos.dart';
import '../theme.dart';
import '../utils.dart';
import '../widgets/action_button.dart';
import 'guia_page.dart';

const _rtoUrl = 'https://www.cent.utn.edu.ar/rto/';
const _rtoProvUrl = 'https://rtosf.3dlink.com.ar/ver_estado.asp';
const _cpeNumero = '2347';
const _senasaUrl = 'https://aps2.senasa.gov.ar/vdc/faces/consulta.jsp';
const _croquisUrl = 'https://6aa19fd84dc76ae390be3ab3--sensational-tanuki-1456af.netlify.app/';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final _busqueda = TextEditingController();
  final _dominio = TextEditingController();
  List<Codigo> _lista = [];
  bool _mostrandoTodos = false;
  bool _tramitesAbierto = false;
  bool _copiado = false;

  bool get _hayDominio => _dominio.text.trim().length >= 5;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted) setState(() => _tramitesAbierto = p.getBool('uor1_tramites_abierto') ?? false);
    });
  }

  @override
  void dispose() {
    _busqueda.dispose();
    _dominio.dispose();
    super.dispose();
  }

  void _buscar(String texto) {
    final q = texto.trim().toUpperCase();
    setState(() {
      _mostrandoTodos = false;
      _lista = q.isEmpty ? [] : codigos.where((x) => x.c.contains(q) || x.d.contains(q)).toList();
    });
  }

  void _toggleTodos() {
    setState(() {
      _mostrandoTodos = !_mostrandoTodos;
      if (_mostrandoTodos) {
        _busqueda.clear();
        _lista = List.of(codigos);
      } else {
        _lista = [];
      }
    });
  }

  Future<void> _toggleTramites() async {
    setState(() => _tramitesAbierto = !_tramitesAbierto);
    final p = await SharedPreferences.getInstance();
    await p.setBool('uor1_tramites_abierto', _tramitesAbierto);
  }

  Future<void> _abrirUrl(String url) async {
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && mounted) toast(context, 'No se pudo abrir el enlace');
  }

  Future<void> _copiarDominio() async {
    final d = _dominio.text.trim();
    final ok = await copiar(d);
    if (!mounted) return;
    if (ok) {
      setState(() => _copiado = true);
      Future.delayed(const Duration(milliseconds: 1600), () {
        if (mounted) setState(() => _copiado = false);
      });
    } else {
      toast(context, 'No se pudo copiar automáticamente: $d');
    }
  }

  Future<void> _consultarWeb(String url, String sufijo) async {
    final d = _dominio.text.trim();
    final ok = await copiar(d);
    if (!mounted) return;
    toast(context, ok ? 'Dominio $d copiado: $sufijo' : 'Copiá el dominio manualmente: $d');
    await _abrirUrl(url);
  }

  Future<void> _consultarCpe() async {
    final d = _dominio.text.trim();
    final uri = Uri(scheme: 'sms', path: _cpeNumero, queryParameters: {'body': 'CPE $d'});
    final ok = await launchUrl(uri);
    if (!ok && mounted) toast(context, 'No se pudo abrir la app de mensajes');
  }

  void _abrirGuia(String id) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => GuiaPage(guiaId: id)));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 680),
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Center(
                  child: Text('UOR1', style: TextStyle(fontSize: 76, fontWeight: FontWeight.w900, color: C.goldSoft, height: 1)),
                ),
                const SizedBox(height: 14),
                Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.04),
                      border: Border.all(color: C.line),
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: const Text('DIRECCIÓN GENERAL GUARDIA PROVINCIAL · SANTA FE',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 11, letterSpacing: 2, color: C.goldSoft, fontWeight: FontWeight.w800)),
                  ),
                ),
                const SizedBox(height: 24),
                _buscador(),
                const SizedBox(height: 20),
                _panelDominio(),
                const SizedBox(height: 20),
                _panelTramites(),
                const SizedBox(height: 20),
                Panel(
                  child: ActionButton(
                    estilo: EstiloBoton.croquis,
                    icono: Icons.map_outlined,
                    titulo: 'Croquis Policial',
                    detalle: 'armar croquis de accidente',
                    onTap: () => _abrirUrl(_croquisUrl),
                  ),
                ),
                const SizedBox(height: 16),
                Center(
                  child: OutlinedButton(
                    onPressed: () => _abrirGuia('modalDetalle'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: C.goldSoft,
                      side: const BorderSide(color: C.line, width: 1.5),
                      shape: const StadiumBorder(),
                    ),
                    child: const Text('ℹ️ Detalle', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'DIRECCIÓN GENERAL GUARDIA PROVINCIAL · UNIDAD OPERATIVA REGIONAL N° 1 — RECONQUISTA',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 10, letterSpacing: 2, color: C.inkFaint, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buscador() {
    final info = _lista.isEmpty
        ? (_busqueda.text.trim().isEmpty ? '' : 'No se encontraron resultados.')
        : (_mostrandoTodos
            ? 'Mostrando los ${_lista.length} códigos disponibles'
            : '${_lista.length} resultado(s) encontrado(s)');
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      TextField(
        controller: _busqueda,
        onChanged: _buscar,
        textCapitalization: TextCapitalization.characters,
        style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
        decoration: InputDecoration(
          hintText: 'Código o palabra clave (alcoholemia, cinturón, matafuego...)',
          hintStyle: const TextStyle(color: C.inkFaint, fontSize: 13),
          prefixIcon: const Icon(Icons.search, color: C.gold),
          filled: true,
          fillColor: Colors.white.withOpacity(0.045),
          contentPadding: const EdgeInsets.symmetric(vertical: 14),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: const BorderSide(color: C.line, width: 1.5)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(30), borderSide: const BorderSide(color: C.gold, width: 1.5)),
        ),
      ),
      const SizedBox(height: 12),
      Center(
        child: FilledButton(
          onPressed: _toggleTodos,
          style: FilledButton.styleFrom(
            backgroundColor: C.gold,
            foregroundColor: const Color(0xFF0A1C2B),
            shape: const StadiumBorder(),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          ),
          child: Text(_mostrandoTodos ? 'Ocultar listado completo' : 'Ver todos los códigos',
              style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
        ),
      ),
      if (info.isNotEmpty)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text(info, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: C.inkDim, fontWeight: FontWeight.w700)),
        ),
      if (_lista.isNotEmpty)
        Container(
          constraints: const BoxConstraints(maxHeight: 420),
          margin: const EdgeInsets.only(top: 8),
          child: ListView.separated(
            shrinkWrap: true,
            itemCount: _lista.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (_, i) {
              final it = _lista[i];
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.04),
                  borderRadius: BorderRadius.circular(12),
                  border: const Border(left: BorderSide(color: C.gold, width: 3)),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Código ${it.c}', style: const TextStyle(fontWeight: FontWeight.w900, color: C.goldSoft, fontSize: 13)),
                  const SizedBox(height: 3),
                  Text(it.d, style: const TextStyle(fontSize: 13, height: 1.4, color: C.inkDim)),
                ]),
              );
            },
          ),
        ),
    ]);
  }

  Widget _panelDominio() {
    return Panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const Text('DOMINIO (PATENTE) — ESCRIBILO A MANO',
            style: TextStyle(fontSize: 12, letterSpacing: 2.5, color: C.gold, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: const Color(0xFFF4F5F2),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: C.line, width: 1.5),
          ),
          child: Row(children: [
            Container(
              width: 24, height: 44,
              decoration: BoxDecoration(
                gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [C.gold, Color(0xFF1C3B55)]),
                borderRadius: BorderRadius.circular(4),
              ),
              child: const RotatedBox(
                quarterTurns: 3,
                child: Center(child: Text('ARGENTINA', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.5, color: Color(0xFF0A0A09)))),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: TextField(
                controller: _dominio,
                maxLength: 8,
                textAlign: TextAlign.center,
                textCapitalization: TextCapitalization.characters,
                autocorrect: false,
                onChanged: (v) {
                  final limpio = v.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
                  if (limpio != v) {
                    _dominio.value = TextEditingValue(text: limpio, selection: TextSelection.collapsed(offset: limpio.length));
                  }
                  setState(() {});
                },
                style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.w700, fontSize: 27, letterSpacing: 3, color: Color(0xFF14161A)),
                decoration: const InputDecoration(
                  counterText: '',
                  border: InputBorder.none,
                  hintText: 'AB123CD',
                  hintStyle: TextStyle(color: Color(0xFF9A9C96)),
                  isDense: true,
                ),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 12),
        Opacity(
          opacity: _hayDominio ? 1 : 0.3,
          child: OutlinedButton.icon(
            onPressed: _hayDominio ? _copiarDominio : null,
            icon: Icon(_copiado ? Icons.check : Icons.copy, size: 16),
            label: Text(_copiado ? 'Copiado ✓' : 'Copiar dominio', style: const TextStyle(fontWeight: FontWeight.w900)),
            style: OutlinedButton.styleFrom(
              foregroundColor: _copiado ? const Color(0xFF0A0A09) : C.lime,
              backgroundColor: _copiado ? C.lime : C.lime.withOpacity(0.08),
              side: BorderSide(color: C.lime.withOpacity(0.55), width: 1.5),
              shape: const StadiumBorder(),
              padding: const EdgeInsets.symmetric(vertical: 13),
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text('Copiá el dominio y pegalo donde lo necesites, o usá los botones de abajo',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 11.5, color: C.inkFaint)),
        const SizedBox(height: 12),
        ActionButton(
          estilo: EstiloBoton.cpe,
          icono: Icons.sms_outlined,
          titulo: 'Consultar CPE',
          detalle: 'Arma el SMS "CPE + dominio" al $_cpeNumero, listo para enviar',
          onTap: _hayDominio ? _consultarCpe : null,
        ),
        const SizedBox(height: 10),
        ActionButton(
          estilo: EstiloBoton.rto,
          icono: Icons.fact_check_outlined,
          titulo: 'Consultar RTO',
          detalle: 'Copia el dominio y abre cent.utn.edu.ar',
          onTap: _hayDominio ? () => _consultarWeb(_rtoUrl, 'pegalo en el formulario') : null,
        ),
        const SizedBox(height: 10),
        ActionButton(
          estilo: EstiloBoton.rto2,
          icono: Icons.flag_outlined,
          titulo: 'Consultar RTO Provincial',
          detalle: 'Copia el dominio y abre RTO Santa Fe (con captcha)',
          onTap: _hayDominio ? () => _consultarWeb(_rtoProvUrl, 'pegalo y resolvé el captcha') : null,
        ),
      ]),
    );
  }

  Widget _panelTramites() {
    return Panel(
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        InkWell(
          onTap: _toggleTramites,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('TRÁMITES Y GUÍAS',
                style: TextStyle(fontSize: 12, letterSpacing: 2.5, color: C.gold, fontWeight: FontWeight.w900)),
            AnimatedRotation(
              turns: _tramitesAbierto ? 0.5 : 0,
              duration: const Duration(milliseconds: 250),
              child: const Icon(Icons.keyboard_arrow_down, color: C.gold),
            ),
          ]),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
          alignment: Alignment.topCenter,
          child: _tramitesAbierto
              ? Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Column(children: [
                    ActionButton(estilo: EstiloBoton.senasa, icono: Icons.eco_outlined, titulo: 'Consultar SENASA CUVE', detalle: 'senasa.gov.ar', onTap: () => _abrirUrl(_senasaUrl)),
                    const SizedBox(height: 10),
                    ActionButton(estilo: EstiloBoton.balanza, icono: Icons.balance, titulo: 'Exceso de peso', detalle: 'guía balanza', onTap: () => _abrirGuia('modalBalanza')),
                    const SizedBox(height: 10),
                    ActionButton(estilo: EstiloBoton.requisa, icono: Icons.shield_outlined, titulo: 'Requisa y secuestro', detalle: 'guía de procedimiento', onTap: () => _abrirGuia('modalArma')),
                    const SizedBox(height: 10),
                    ActionButton(estilo: EstiloBoton.juvenil, icono: Icons.person_outline, titulo: 'Régimen Penal Juvenil', detalle: 'ley 27.801', onTap: () => _abrirGuia('modalMenores')),
                    const SizedBox(height: 10),
                    ActionButton(estilo: EstiloBoton.microtrafico, icono: Icons.science_outlined, titulo: 'Ley de Microtráfico', detalle: 'ley 14.239', onTap: () => _abrirGuia('modalMicrotrafico')),
                    const SizedBox(height: 10),
                    ActionButton(estilo: EstiloBoton.federal, icono: Icons.account_balance_outlined, titulo: 'Procedimiento Federal', detalle: 'narcotráfico · actas y derechos del imputado', onTap: () => _abrirGuia('modalFederal')),
                    const SizedBox(height: 10),
                    ActionButton(
                      estilo: EstiloBoton.protocolo,
                      icono: Icons.picture_as_pdf_outlined,
                      titulo: 'Protocolo Policial',
                      detalle: 'abrir PDF',
                      onTap: () => abrirDocumento(context, 'assets/docs/protocolo_policial_flagrancia.pdf'),
                    ),
                    const SizedBox(height: 10),
                    ActionButton(estilo: EstiloBoton.actas, icono: Icons.assignment_outlined, titulo: 'Actas Complementarias', detalle: 'modelos Word/ODT para descargar', onTap: () => _abrirGuia('modalActasComplementarias')),
                  ]),
                )
              : const SizedBox(width: double.infinity),
        ),
      ]),
    );
  }
}
