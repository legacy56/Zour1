import 'package:flutter/material.dart';
import 'screens/splash_page.dart';
import 'theme.dart';

void main() {
  runApp(const Uor1App());
}

class Uor1App extends StatelessWidget {
  const Uor1App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'UOR 1',
      debugShowCheckedModeBanner: false,
      theme: construirTema(),
      home: const SplashPage(),
    );
  }
}
