import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme.dart';

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg, textAlign: TextAlign.center,
          style: const TextStyle(fontWeight: FontWeight.w700, color: C.ink)),
      backgroundColor: C.panel,
      behavior: SnackBarBehavior.floating,
      shape: StadiumBorder(side: BorderSide(color: C.line)),
      duration: const Duration(milliseconds: 2600),
    ));
}

/// Copia al portapapeles. Devuelve true si salió bien.
Future<bool> copiar(String texto) async {
  try {
    await Clipboard.setData(ClipboardData(text: texto));
    return true;
  } catch (_) {
    return false;
  }
}
