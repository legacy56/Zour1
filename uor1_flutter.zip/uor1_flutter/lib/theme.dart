import 'package:flutter/material.dart';

/// Paleta tomada del CSS original (index.html).
class C {
  static const bg0 = Color(0xFF020202);
  static const bg1 = Color(0xFF0A0A09);
  static const panel = Color(0xFF111210);
  static const gold = Color(0xFF6FB7E8);
  static const goldSoft = Color(0xFFCFE9FF);
  static const lime = Color(0xFFC6FF3D);
  static const ink = Color(0xFFF5F3EC);
  static const inkDim = Color(0xFFB9B6A8);
  static const inkFaint = Color(0xFF7A7768);
  static const line = Color(0x386FB7E8); // gold al 22 %
  static const lineSoft = Color(0x0FFFFFFF); // blanco al 6 %
}

/// Degradado + color de texto de cada botón de acción.
class EstiloBoton {
  final Color a;
  final Color b;
  final Color fg;
  const EstiloBoton(this.a, this.b, this.fg);

  static const cpe = EstiloBoton(Color(0xFFFFC46B), Color(0xFFFF9D2E), Color(0xFF231200));
  static const rto = EstiloBoton(Color(0xFFD4FF5C), Color(0xFFA6E600), Color(0xFF0B0D0A));
  static const rto2 = EstiloBoton(Color(0xFF7FD8FF), Color(0xFF38A9E6), Color(0xFF031B28));
  static const senasa = EstiloBoton(Color(0xFF9BF27A), Color(0xFF4FBF3C), Color(0xFF0D2B06));
  static const balanza = EstiloBoton(Color(0xFFFFE37A), Color(0xFFF0B429), Color(0xFF3A2A00));
  static const requisa = EstiloBoton(Color(0xFFFF8F83), Color(0xFFEF4A3A), Color(0xFF380A06));
  static const juvenil = EstiloBoton(Color(0xFFDCB3FF), Color(0xFFA85BF0), Color(0xFF28084A));
  static const microtrafico = EstiloBoton(Color(0xFF7CF0DD), Color(0xFF22B3A0), Color(0xFF04302B));
  static const federal = EstiloBoton(Color(0xFF8FB8FF), Color(0xFF3F6FD6), Color(0xFF062233));
  static const protocolo = EstiloBoton(Color(0xFFDFE6EC), Color(0xFFAAB7C2), Color(0xFF131C22));
  static const actas = EstiloBoton(Color(0xFFFFD27A), Color(0xFFE8A13D), Color(0xFF241300));
  static const croquis = EstiloBoton(Color(0xFFFF9ECF), Color(0xFFE13D8F), Color(0xFF3A0322));
}

ThemeData construirTema() {
  return ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    scaffoldBackgroundColor: C.bg0,
    colorScheme: const ColorScheme.dark(primary: C.gold, surface: C.panel),
  );
}
