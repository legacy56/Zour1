import 'package:flutter/material.dart';
import '../theme.dart';

class ActionButton extends StatelessWidget {
  final EstiloBoton estilo;
  final IconData icono;
  final String titulo;
  final String? detalle;
  final VoidCallback? onTap; // null = deshabilitado

  const ActionButton({
    super.key,
    required this.estilo,
    required this.icono,
    required this.titulo,
    this.detalle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: onTap == null ? 0.35 : 1,
      child: Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [estilo.a, estilo.b]),
            borderRadius: BorderRadius.circular(14),
            boxShadow: [BoxShadow(color: estilo.b.withOpacity(0.26), blurRadius: 18, offset: const Offset(0, 6))],
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(children: [
                Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(color: Colors.black.withOpacity(0.22), borderRadius: BorderRadius.circular(11)),
                  child: Icon(icono, size: 20, color: estilo.fg),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(titulo, style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15, color: estilo.fg)),
                    if (detalle != null)
                      Text(detalle!, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12, color: estilo.fg.withOpacity(0.8))),
                  ]),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

/// Contenedor tipo "panel" con borde celeste.
class Panel extends StatelessWidget {
  final Widget child;
  const Panel({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(18, 20, 18, 22),
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [C.panel, C.bg1]),
        border: Border.all(color: C.line),
        borderRadius: BorderRadius.circular(22),
        boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 35, offset: Offset(0, 10))],
      ),
      child: child,
    );
  }
}
