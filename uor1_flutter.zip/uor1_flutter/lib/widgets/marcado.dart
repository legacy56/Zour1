import 'package:flutter/material.dart';

/// Convierte "texto <b>negrita</b> <i>cursiva</i>" en TextSpans.
List<InlineSpan> parseMarcado(String m, {Color? colorNegrita}) {
  final spans = <InlineSpan>[];
  final re = RegExp(r'<(b|i)>(.*?)</\1>', dotAll: true);
  var pos = 0;
  for (final mt in re.allMatches(m)) {
    if (mt.start > pos) spans.add(TextSpan(text: m.substring(pos, mt.start)));
    final esB = mt.group(1) == 'b';
    spans.add(TextSpan(
      text: mt.group(2),
      style: esB
          ? TextStyle(fontWeight: FontWeight.w900, color: colorNegrita)
          : const TextStyle(fontStyle: FontStyle.italic),
    ));
    pos = mt.end;
  }
  if (pos < m.length) spans.add(TextSpan(text: m.substring(pos)));
  return spans;
}
